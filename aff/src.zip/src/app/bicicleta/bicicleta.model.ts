export class Bicicleta {
    constructor(
        public id: number,
        public status: number,
        public uid: number
    ){}
}