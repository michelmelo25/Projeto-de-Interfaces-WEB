export class Usuario {
    constructor(
        public nome: string,
        public email: string
    ){}
}